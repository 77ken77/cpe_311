# Github page
The file index.html contains a Philippine covid-19 info with plots using bokeh. You can view this page at https://fsmosca.github.io/COVID-19-PH-dataset
